clc;
clear;
close all;

% % % Initialization 
[imagename1 imagepath1]=uigetfile('input\*.jpg;*.bmp;*.png;*.tif;*.tiff;*.pgm;*.gif','Please choose the first input image');
f1=imread(strcat(imagepath1,imagename1));    
[imagename2 imagepath2]=uigetfile('input\*.jpg;*.bmp;*.png;*.tif;*.tiff;*.pgm;*.gif','Please choose the second input image');
f2=imread(strcat(imagepath2,imagename2)); 
s=size(f1);
n=s(1).*s(2);
figure,imshow(f1),title('input image-1');
figure,imshow(f2),title('input image-2');
tic;
f1= 1.15.*(f1);
f2= 1.15.*(f2);

% % % First input image

f1_new=reshape(f1,[],1);
f1_new=double(f1_new);
[Y,A,om_r,dev]=hvd(f1_new,1,0.041);
for i=1:n
    d(i)=Y(i,1);
end
d=d';
r1=f1_new-d;
Y=reshape(Y,s(1),s(2));
r1=reshape(r1,s(1),s(2));
figure(),imshow(Y,[]);
figure(),imshow(r1,[]);

% % % Second input image

f2_new=reshape(f2,[],1);
f2_new=double(f2_new);
[X,B,om_rr1,dev1]=hvd(f2_new,1,0.041);
for i=1:n
    d1(i)=X(i,1);
end
d1=d1';
r2=f2_new-d1;
X=reshape(X,s(1),s(2));
r2=reshape(r2,s(1),s(2));
figure(),imshow(X,[]);
figure(),imshow(r2,[]);

%%%%%Filtering
Y = imguidedfilter(Y); %1st input image 1st image amplitude
X = imguidedfilter(X); %2nd input image 1st image amplitude
r1 = imguidedfilter(r1); %1st input image 2nd image amplitude
r2 = imguidedfilter(r2); %2nd input image 2nd image amplitude
% % % Fusion
level=4;
% 1st energy component
F1 = lp_fuse(Y,X,level,3,3);       %LP
% 2nd energy component
F2 = lp_fuse(r1,r2,level,3,3);       %LP
F = F1+F2;
figure(),imshow(uint8(F))
F=(uint8(F));
toc;
